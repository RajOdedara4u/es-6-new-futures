const data = { nam: "raj", age: 19, clg: "grkl" };
const data2 = { nam: nam, age: age, clg: clg }; // copy of first object
const data3 = { nam, age, clg }; //advance method it will copy the first object data
const { nam, age, clg } = data3;
console.log(`my name is ${nam} , age${age} clg is ${clg}`);
