//default argument are the value which was given the function paramiter when function was crated

function fun(price = 1999) {
  console.log(price);
}

fun(); // it will take default argument
fun(25000);
