//           functions are the block of code which we can access by the singe word

//              old method to declare function

function fun() {
  console.log("This is old function style...");
}

//              new function method to declare

const fun1 = () => {
  console.log("This is new method");
};

const sum = (a, b) => {
  console.log(a + b);
};

fun();
fun1();
sum(10, 20);
