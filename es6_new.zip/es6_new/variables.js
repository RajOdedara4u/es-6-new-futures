/*                      **  CONST   **
            - we can not re-declare cons variable again 
            - we can not change the value of const
       

                        **    LET    **  
            - we can create multiple variables 
            - we can change valus
            - block scope avalable       
            
                        **      var     **

            - this is normal and old variable 
            - it have globle scop
*/

//  let--------------------------------------------------------------------------------

function fun() {
  let a = 10;
  if (true) {
    let a = 20; //block scope...
    console.log("in block a" + a);
  }
  console.log("outer block a " + a);
}
fun();

//const--------------------------------------------------------------------------------
function fun2() {
  const a = 10;
  // a=22; //gives error for assign value again
  console.log("thi is constant : " + a);
}
fun2();

//var--------------------------------------------------------------------------------
function fun3() {
  var x = 10;                             //it have a function scop then any part of function can access it
  if (true) {
    var x = 20;
    console.log("this is var " + x);
  }
  console.log("this is var " + x);
}
fun3();
