// destructuring mens access the properties of object whiout using obect nam

//  ex ob1={d1=2,d2=3}
//     - use  obj1.d1;

//-use in distru...
//const = { d1 d2 }  now just d1 is aaccessable

const data = { nam: "raj", age: 19, clg: "grkl" };

console.log("simple use obj.nam  :" + data.nam); //normal use

const { nam, age } = data;

console.log("after destructuring nam   :" + nam);
