const ob = { nam: "raj", age: "19", clg: "grkl" };

const { nam, age, clg } = ob; //destructuring object....

// before tamplate String
const data =
  "my name is " + nam + " my age is " + age + " my college is " + clg;
console.log(data);

//after tamplate string future

const d1 = `my name is ${nam} , my age is ${age} , my college is ${clg}`;
console.log(d1);
